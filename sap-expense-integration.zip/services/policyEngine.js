const rules = require('../data/policy-rules.json');

function jobGradeNumber(grade) {
  // "M3" -> 3, "M6" -> 6
  const match = String(grade).match(/(\d+)/);
  return match ? Number(match[1]) : 0;
}

function gradeBand(gradeNum) {
  if (gradeNum <= 3) return 'low';
  if (gradeNum <= 5) return 'mid';
  return 'high';
}

/**
 * Evaluates one expense line against policy rules using employee context
 * pulled from HCM. Returns a decision the approval router and auto-coder
 * both depend on.
 */
function evaluateExpense(expense, employee) {
  const violations = [];
  const gradeNum = jobGradeNumber(employee.JobGrade);

  const rule = rules.eligibilityRules.find((r) => r.category === expense.category);
  if (rule) {
    if (rule.category === 'Airfare - international' && expense.fareClass === 'business') {
      if (gradeNum < rule.eligibility.minJobGradeNumber) {
        violations.push({ ruleId: rule.ruleId, severity: rule.onViolation.severity, message: rule.onViolation.message });
      }
    }
    if (rule.category === 'Hotel') {
      const band = gradeBand(gradeNum);
      const cap = rule.eligibility.maxNightlyRateByGrade[band];
      if (expense.amount > cap) {
        violations.push({ ruleId: rule.ruleId, severity: rule.onViolation.severity, message: rule.onViolation.message });
      }
    }
    if (rule.category === 'Client meal') {
      const perHead = expense.attendeeCount ? expense.amount / expense.attendeeCount : expense.amount;
      if (perHead > rule.eligibility.maxPerHead) {
        violations.push({ ruleId: rule.ruleId, severity: rule.onViolation.severity, message: rule.onViolation.message });
      }
    }
  }

  const hasBlock = violations.some((v) => v.severity === 'block');
  const status = hasBlock ? 'blocked' : violations.length ? 'flagged' : 'compliant';

  return { status, violations };
}

module.exports = { evaluateExpense };
